@echo off
setlocal
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter is not installed or is not on PATH.
  echo Install Flutter from https://docs.flutter.dev/get-started/install
  pause
  exit /b 1
)
flutter create . --platforms=android
if errorlevel 1 exit /b 1
flutter pub get
if errorlevel 1 exit /b 1
flutter build apk --release
if errorlevel 1 exit /b 1
echo.
echo APK output:
echo build\app\outputs\flutter-apk\app-release.apk
pause
