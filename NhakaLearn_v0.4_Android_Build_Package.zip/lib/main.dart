import 'package:flutter/material.dart';

void main() => runApp(const NhakaLearnApp());

const brand = Color(0xFF176B55);
const grades = ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7'];
const areas = [
  'Indigenous Languages', 'English Language', 'Mathematics',
  'Science and Technology', 'Social Science', 'Physical Education and Arts'
];

class NhakaLearnApp extends StatelessWidget {
  const NhakaLearnApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NhakaLearn',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: brand),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF6F8F6),
      ),
      home: const WelcomeScreen(),
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              const CircleAvatar(
                radius: 42, backgroundColor: brand,
                child: Icon(Icons.school, color: Colors.white, size: 42),
              ),
              const SizedBox(height: 18),
              const Text('NhakaLearn', textAlign: TextAlign.center,
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: brand)),
              const Text('Learn. Grow. Celebrate our heritage.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 15)),
              const SizedBox(height: 36),
              const Text('Choose how you want to continue',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
              const SizedBox(height: 14),
              _roleButton(context, 'I am a Learner', Icons.menu_book, () =>
                Navigator.push(context, MaterialPageRoute(builder: (_) => const LearnerDashboard()))),
              _roleButton(context, 'I am a Teacher', Icons.cast_for_education, () =>
                Navigator.push(context, MaterialPageRoute(builder: (_) => const TeacherDashboard()))),
              _roleButton(context, 'I am a Parent / Guardian', Icons.family_restroom, () =>
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ParentDashboard()))),
              const Spacer(),
              const Text('Prototype v0.4 • Demonstration data only',
                textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _roleButton(BuildContext context, String label, IconData icon, VoidCallback onTap) =>
    Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: FilledButton.tonalIcon(
        onPressed: onTap, icon: Icon(icon), label: Padding(
          padding: const EdgeInsets.symmetric(vertical: 13), child: Text(label)),
      ),
    );
}

class LearnerDashboard extends StatelessWidget {
  const LearnerDashboard({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('NhakaLearn • Learner')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const _WelcomeCard(title: 'Welcome back!', subtitle: 'Grade 1 • Keep learning every day.'),
      const SizedBox(height: 18),
      const Text('Your learning areas', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      ...areas.map((a) => Card(child: ListTile(
        leading: const CircleAvatar(backgroundColor: Color(0xFFE2F1E9), child: Icon(Icons.auto_stories, color: brand)),
        title: Text(a), subtitle: const Text('Explore topics and activities'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LessonScreen(area: a))),
      ))),
      const SizedBox(height: 12),
      const _InfoNote(text: 'Heritage Corner: discover our stories, values, places, skills and traditions.'),
    ]),
  );
}

class TeacherDashboard extends StatefulWidget {
  const TeacherDashboard({super.key});
  @override
  State<TeacherDashboard> createState() => _TeacherDashboardState();
}

class _TeacherDashboardState extends State<TeacherDashboard> {
  final className = TextEditingController(text: 'Grade 1 Blue');
  String inviteCode = 'NHK-1B24';
  final List<String> learners = ['Tariro M.', 'Tawanda C.', 'Rudo N.', 'Kudzai P.'];
  String assignedLesson = 'Tangible Heritage';

  @override
  void dispose() { className.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Teacher dashboard')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const _WelcomeCard(title: 'Good day, Teacher', subtitle: 'Manage your class and support learning.'),
      const SizedBox(height: 16),
      _sectionTitle('My class'),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextField(controller: className, decoration: const InputDecoration(labelText: 'Class name', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Demo joining code', style: TextStyle(color: Colors.black54)),
              SelectableText(inviteCode, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: brand)),
            ])),
            IconButton(onPressed: () => setState(() => inviteCode = 'NHK-${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}'),
              icon: const Icon(Icons.refresh), tooltip: 'Generate another demo code'),
          ]),
          const Text('Share this code with learners or parents. It is not connected to a real account system.',
            style: TextStyle(fontSize: 12, color: Colors.black54)),
        ],
      ))),
      _sectionTitle('Learner roster • ${learners.length} sample learners'),
      Card(child: Column(children: learners.map((name) => ListTile(
        leading: const CircleAvatar(child: Icon(Icons.person)),
        title: Text(name), subtitle: const Text('Grade 1 • Demo learner'),
      )).toList())),
      _sectionTitle('Assign a lesson'),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        DropdownButtonFormField<String>(
          value: assignedLesson,
          decoration: const InputDecoration(labelText: 'Select lesson', border: OutlineInputBorder()),
          items: ['Tangible Heritage', 'Counting to 20', 'Living and non-living things']
            .map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
          onChanged: (v) { if (v != null) setState(() => assignedLesson = v); },
        ),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: () => _message(context, '“$assignedLesson” marked as assigned (demo only).'),
          icon: const Icon(Icons.send), label: const Text('Assign to class')),
      ]))),
      _sectionTitle('Class results'),
      Card(child: Column(children: const [
        ListTile(leading: Icon(Icons.check_circle, color: brand), title: Text('Tangible Heritage quiz'), subtitle: Text('Average score: 4/5 • Sample data')),
        ListTile(leading: Icon(Icons.trending_up), title: Text('Learner participation'), subtitle: Text('3 of 4 sample learners completed the activity')),
      ])),
      const _InfoNote(text: 'Teacher tools are demonstrations. Class records, assignments and results are not saved or shared yet.'),
    ]),
  );
}

class ParentDashboard extends StatefulWidget {
  const ParentDashboard({super.key});
  @override
  State<ParentDashboard> createState() => _ParentDashboardState();
}

class _ParentDashboardState extends State<ParentDashboard> {
  final codeController = TextEditingController();
  String childName = 'Tariro M.';
  bool linked = true;

  @override
  void dispose() { codeController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Parent dashboard')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const _WelcomeCard(title: 'Your child’s learning', subtitle: 'Stay involved and encourage steady progress.'),
      const SizedBox(height: 16),
      _sectionTitle('Link a learner'),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
        children: [
          TextField(controller: codeController, textCapitalization: TextCapitalization.characters,
            decoration: const InputDecoration(labelText: 'Enter school / class joining code', hintText: 'e.g. NHK-1B24', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: FilledButton(
            onPressed: () {
              if (codeController.text.trim().isEmpty) {
                _message(context, 'Enter a joining code to try the demo.');
              } else {
                setState(() { linked = true; childName = 'Demo learner'; });
                _message(context, 'Demo learner linked for this screen only.');
              }
            }, child: const Text('Link learner (demo)'))),
          const Text('Use a code provided by your child’s verified school. Do not enter private information in this prototype.',
            style: TextStyle(fontSize: 12, color: Colors.black54)),
        ],
      ))),
      _sectionTitle('Child progress'),
      if (linked) ...[
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(childName, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const Text('Grade 1 • Sample profile'),
            const SizedBox(height: 14),
            const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Learning progress'), Text('60%', style: TextStyle(fontWeight: FontWeight.bold, color: brand)),
            ]),
            const SizedBox(height: 8),
            const LinearProgressIndicator(value: .6, minHeight: 9),
            const SizedBox(height: 14),
            const ListTile(contentPadding: EdgeInsets.zero, leading: Icon(Icons.check_circle, color: brand),
              title: Text('Tangible Heritage'), subtitle: Text('Lesson completed • Sample record')),
            const ListTile(contentPadding: EdgeInsets.zero, leading: Icon(Icons.pending_actions),
              title: Text('Counting to 20'), subtitle: Text('In progress • Sample record')),
          ],
        ))),
      ] else const _InfoNote(text: 'Link a learner to see their progress here.'),
      const _InfoNote(text: 'Parent-child linking and progress reports are not connected to a secure database yet.'),
    ]),
  );
}

class LessonScreen extends StatelessWidget {
  final String area;
  const LessonScreen({super.key, required this.area});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(area)),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Grade 1 • Sample topic', style: TextStyle(color: brand, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Tangible Heritage', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      const Text('Heritage includes things from the past that people value and pass on to future generations. Tangible heritage refers to things we can see and touch.'),
      const SizedBox(height: 14),
      const _InfoNote(text: 'Examples can include traditional clay pots, baskets, monuments and important heritage sites.'),
      const SizedBox(height: 14),
      const Text('Try this activity', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const Text('Draw or name one example of tangible heritage found in your community.'),
      const SizedBox(height: 20),
      FilledButton(onPressed: () => _message(context, 'Activity marked complete (demo only).'),
        child: const Text('Mark activity complete')),
      const SizedBox(height: 12),
      OutlinedButton(onPressed: () => _message(context, 'Correct answer: a traditional clay pot.'),
        child: const Text('Check sample quiz answer')),
    ]),
  );
}

class _WelcomeCard extends StatelessWidget {
  final String title, subtitle;
  const _WelcomeCard({required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: brand, borderRadius: BorderRadius.circular(18)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 5),
      Text(subtitle, style: const TextStyle(color: Colors.white)),
    ]),
  );
}

class _InfoNote extends StatelessWidget {
  final String text;
  const _InfoNote({required this.text});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: const Color(0xFFEAF3EE), borderRadius: BorderRadius.circular(12)),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Icon(Icons.lightbulb_outline, color: brand),
      const SizedBox(width: 10),
      Expanded(child: Text(text)),
    ]),
  );
}

Widget _sectionTitle(String text) => Padding(
  padding: const EdgeInsets.only(top: 18, bottom: 8),
  child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
);

void _message(BuildContext context, String text) =>
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
